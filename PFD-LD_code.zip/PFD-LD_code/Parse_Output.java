import java.util.ArrayList;
import java.util.HashMap;

public class Parse_Output {
    ArrayList<Integer> all_nodes;
    ArrayList<ArrayList<Edge>> all_edges;
    ArrayList<HashMap<Edge, Constraint>> all_cons;
    ArrayList<HashMap<Edge, Double>> all_belief;

    public Parse_Output(ArrayList<Integer> all_nodes, ArrayList<ArrayList<Edge>> all_edges, ArrayList<HashMap<Edge, Constraint>> all_cons) {
        this.all_nodes = all_nodes;
        this.all_edges = all_edges;
        this.all_cons = all_cons;
        this.all_belief = cal_Belief(all_nodes,all_edges,all_cons);
    }
    @Override
    public String toString() {
        return "Parse_Output{" +
                "all_nodes=" + all_nodes +
                ", all_edges=" + all_edges +
                ", all_cons=" + all_cons +
                '}';
    }
    private ArrayList<HashMap<Edge, Double>> cal_Belief(ArrayList<Integer> all_nodes, ArrayList<ArrayList<Edge>> all_edges, ArrayList<HashMap<Edge, Constraint>> all_cons){
        ArrayList<HashMap<Edge, Double>> temp = new ArrayList<>() ;

        return temp;
    }
}
