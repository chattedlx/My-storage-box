import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.IntStream;

public class Agent{
    protected int suc_cnt = 0;
    protected int fail_cnt = 0;
    protected int sc = 15;
    protected int fc = 5;
    protected double  row = 1;

    protected boolean isMax;
    protected MailManager[] mailManager;
    protected int agentNo;
    private String agentName;
    protected int population;
    protected double domain_lb, domain_ub;

    protected double[] velocity;

    protected double[] position;
    protected double[] position_belief;
    protected HashMap<Integer, double[]> inbox;
    protected HashMap<Integer, double[]> inbox_tocalbelief;
    private HashMap<Integer, double[]> cons_inbox;
    private HashMap<Integer, double[]> cons_inbox_tocalbelief;

    public double getGbest_val() {
        return gbest_val;
    }
    public double getGbest_val_belief(){
        return gbest_val_belief;
    }

    protected double[] pbest_val;
    protected double gbest_val;
    protected double last_gbest;
    protected double gbest_val_belief;
    protected double[] pbest_position;
    protected double gbest_position;
    protected double[] pbestParticleNo;
    protected double gbestParticleNo;

    protected Vector<Integer> neighbors;
    private int parent;
    protected Vector<Integer> child;

    public int getCurrentIter() {
        return currentIter;
    }

    public void setCurrentIter(int currentIter) {
        this.currentIter = currentIter;
    }

    protected int currentIter = 0;

    public int getMaxIteration() {
        return maxIteration;
    }

    private int maxIteration;

    protected ArrayList<Edge> edgelist;
    protected int[][] indexToEdge;
    protected HashMap<Edge, Constraint> constraints;
    protected double[] cons_cost;
    protected double[] cons_cost_tocalbelief;

    protected double[] globalRootCost;
    protected double[] globalRootCost_tocalbelief;
    double w;

    public void setW(double w) {
        this.w = w;
    }

    public void setC1(double c1) {
        this.c1 = c1;
    }

    public void setC2(double c2) {
        this.c2 = c2;
    }

    double c1;
    double c2;
    long starttime;

    public MailManager[] getMailManager() {
        return mailManager;
    }

    Agent(MailManager[] mailManager, int AgentNo, Vector<Integer> neighbors, int parent, Vector<Integer> child, int population, double domain_lb, double domain_ub, int maxIteration, boolean ismax, ArrayList<Edge> edgelist, int[][] indexToEdge, HashMap<Edge, Constraint> constraints, double w, double c1, double c2)
    {
        this.mailManager = mailManager;
        this.agentNo = AgentNo;
        this.agentName = "Agent-"+this.agentNo;
        this.population = population;
        this.domain_lb = domain_lb;
        this.domain_ub = domain_ub;
        this.velocity = new double[this.population];
        this.position = new double[this.population];
        this.position_belief=new double[1];
        this.inbox = new HashMap<>();
        this.inbox_tocalbelief= new HashMap<>();
        this.cons_inbox = new HashMap<>();
        this.cons_inbox_tocalbelief= new HashMap<>();

        this.pbest_position = new double[this.population];
        this.cons_cost = new double[this.population];
        this.cons_cost_tocalbelief=new double[1];
        this.pbestParticleNo = new double[this.population+1];
        Arrays.fill(this.pbestParticleNo, -1);
        this.gbestParticleNo = -1;

        this.neighbors = neighbors;
        this.parent = parent;
        this.child = child;

        this.maxIteration = maxIteration;

        this.edgelist = edgelist;
        this.indexToEdge = indexToEdge;
        this.constraints = constraints;
        this.globalRootCost = new double[this.population];
        this.globalRootCost_tocalbelief=new double[1];

        this.isMax = ismax;

        if(ismax)
        {
            this.pbest_val = new double[this.population];
            Arrays.fill(this.pbest_val, Double.MIN_VALUE);
            this.gbest_val = Double.MIN_VALUE;
            this.last_gbest = Double.MIN_VALUE;

        }
        else {
            this.pbest_val = new double[this.population];
            Arrays.fill(this.pbest_val, Double.MAX_VALUE);
            this.gbest_val = Double.MAX_VALUE;
            this.last_gbest = Double.MAX_VALUE;
        }
        this.w = w;
        this.c1 = c1;
        this.c2 = c2;
        this.starttime = System.currentTimeMillis();
    }


    public double cal_row() {
        if (this.fail_cnt > this.fc)
        {
            this.row = 0.5 * this.row;
        }

        else if(this.suc_cnt > this.sc)
        {
            this.row = Math.min(2 * this.row, 1000);
        }
        else
        {
            this.row = this.row;

        }
        return this.row;
    }

    public void initValues() {
        for(int i = 0; i< this.population; i++)
        {
            double randomValue = ((Math.random() * (this.domain_ub - this.domain_lb)) + this.domain_lb);
            assert(randomValue <= this.domain_ub && randomValue >= this.domain_lb);
            this.position[i] = randomValue;
            this.velocity[i] = 0;
        }
    }

    public void updateValues() {
        double ub = 1.0;
        double lb = 0.0;
        double r1 = (Math.random() * (ub - lb)) + lb;
        double r2 = (Math.random() * (ub - lb)) + lb;
        int de1 = (int)(Math.random()*(this.population));
        int de2 = (int)(Math.random()*(this.population));
        for(int i = 0; i < population; i++)
        {
            if(i==this.gbestParticleNo)
            {
                this.velocity[i] = -this.position[i] + this.gbest_position + (w * this.velocity[i]) + cal_row() * (1- (2 * r2));
                this.position[i] = this.position[i] + this.velocity[i];
            }
            else{
                this.velocity[i] = w * this.velocity[i] + c1 * r1 * (this.pbest_position[i] - this.position[i]) + c2 * r2 * (this.gbest_position - this.position[i]);
                this.position[i] = this.position[i] + this.velocity[i];
                if (Math.random()<0.1)
                {
                    position[i]= position[i] + 0.1 *(this.pbest_position[de1]-position[i])+(1-0.1)*(this.pbest_position[de1]-position[de2]);
                }
            }
            if(this.position[i] < this.domain_lb)
            {
                this.position[i] = this.domain_lb;
            }
            if(this.position[i] > this.domain_ub){

                this.position[i] = this.domain_ub;
            }

        }
    }

    public void sendValueMessage() throws InterruptedException {
        for(int neigh: neighbors) {
            Message valueMsg = new Message(this.agentNo, neigh, 202, this.position);
            this.mailManager[neigh].putMessage(valueMsg);
        }
    }

    public void receiveValueMessage() throws InterruptedException {
        int cnt = 0;
        while (cnt < neighbors.size())
        {
            Message rcvdValueMsg = this.mailManager[this.agentNo].getMessage();
            this.inbox.put(rcvdValueMsg.getSenderId(), rcvdValueMsg.getMsgContent());
            cnt += 1;
        }
    }

    public void calculateCost() {
        double[] consCostList = new double[this.population];
        Arrays.fill(consCostList, 0.0);
        for (int neigh: neighbors)
        {
            Constraint cons = this.constraints.get(edgelist.get(indexToEdge[this.agentNo][neigh]));
            for(int i=0; i<population; i++)
            {
                double cons_calc = cons.getA() * Math.pow(this.position[i], 2) + cons.getB() * this.position[i] + cons.getC() * this.position[i] * this.inbox.get(neigh)[i] + cons.getD() * this.inbox.get(neigh)[i] + cons.getE() * Math.pow(this.inbox.get(neigh)[i], 2) + cons.getF();
                consCostList[i] += cons_calc;
            }
        }
        this.cons_cost = consCostList;
        int min_label = IntStream.range(0, consCostList.length).reduce((k, j) -> consCostList[k] > consCostList[j] ? j : k).getAsInt();
        this.position_belief[0] = position[min_label];
    }

    public void sendValueMessage_tocalbelief() throws InterruptedException {
        for(int neigh: neighbors)
        {
            Message valueMsg_tocalbelief = new Message(this.agentNo, neigh, 210, this.position_belief);
            this.mailManager[neigh].putMessage_tocalbelief(valueMsg_tocalbelief);
        }
    }

    public void receiveValueMessage_tocalbelief() throws InterruptedException {
        int cnt = 0;
        while (cnt < neighbors.size())
        {
            Message rcvdValueMsg_tocalbelief = this.mailManager[this.agentNo].getMessage_tocalbelief();
            this.inbox_tocalbelief.put(rcvdValueMsg_tocalbelief.getSenderId(), rcvdValueMsg_tocalbelief.getMsgContent());
            cnt += 1;
        }
    }

    public void calculateCost_tocalbelief() {
        double[] consCostList_1 = new double[1];
        Arrays.fill(consCostList_1, 0.0);
        for (int neigh : neighbors) {
            Constraint cons_1 = this.constraints.get(edgelist.get(indexToEdge[this.agentNo][neigh]));
            double cons_calc_1 = cons_1.getA() * Math.pow(this.position_belief[0], 2) + cons_1.getB() * this.position_belief[0] + cons_1.getC() * this.position_belief[0] * this.inbox_tocalbelief.get(neigh)[0] + cons_1.getD() * this.inbox_tocalbelief.get(neigh)[0] + cons_1.getE() * Math.pow(this.inbox_tocalbelief.get(neigh)[0], 2) + cons_1.getF();
            consCostList_1[0] += cons_calc_1;
        }
        this.cons_cost_tocalbelief = consCostList_1;
    }

    public void sendCostMessage_tocalbelief() throws InterruptedException {
        double[] sumChildCost_2 = new double[1];
        Arrays.fill(sumChildCost_2, 0.0);
        for(int baccha: child)
        {
            sumChildCost_2[0] += this.cons_inbox_tocalbelief.get(baccha)[0];
        }
        double[] sumTotalCost_2 = new double[1];
        sumTotalCost_2[0] = sumChildCost_2[0] + this.cons_cost_tocalbelief[0];
        int neigh = this.parent;
        Message costMsg_tocalbelief = new Message(this.agentNo, neigh, 211, sumTotalCost_2);
        this.mailManager[neigh].putCostMessage_tocalbelief(costMsg_tocalbelief);
    }

    public void receiveCostMessage_tocalbelief() throws InterruptedException {
        int cnt = 0;
        while (cnt < child.size())
        {
            Message rcvdCostValueMsg_tocalbelief = this.mailManager[this.agentNo].getCostMessage_tocalbelief();
            this.cons_inbox_tocalbelief.put(rcvdCostValueMsg_tocalbelief.getSenderId(), rcvdCostValueMsg_tocalbelief.getMsgContent());
            cnt += 1;
        }

    }

    public void sumRootChildCost_tocalbelief() throws InterruptedException {
        double[] sumChildCost_1 = new double[1];
        Arrays.fill(sumChildCost_1, 0.0);
        for(int baccha: child)
        {
            sumChildCost_1[0] += this.cons_inbox_tocalbelief.get(baccha)[0];
        }
        this.globalRootCost_tocalbelief[0] = sumChildCost_1[0] + this.cons_cost_tocalbelief[0];
        this.globalRootCost_tocalbelief[0] /= 2;
        this.gbest_val_belief=this.globalRootCost_tocalbelief[0];
        if (this.gbest_val_belief<this.last_gbest)
        {
            this.last_gbest = this.gbest_val_belief;
        }
        else {
            this.gbest_val_belief = this.last_gbest;
        }
    }

    public void sendCostMessage() throws InterruptedException {
        double[] sumChildCost = new double[this.population];
        Arrays.fill(sumChildCost, 0.0);
        for(int baccha: child)
        {
            for(int i = 0; i < population; i++)
            {
                sumChildCost[i] += this.cons_inbox.get(baccha)[i];
            }
        }
        double[] sumTotalCost = new double[this.population];
        for(int i = 0; i < population; i++)
        {
            sumTotalCost[i] = sumChildCost[i] + this.cons_cost[i];
        }
        int neigh = this.parent;
        Message costMsg = new Message(this.agentNo, neigh, 204, sumTotalCost);
        this.mailManager[neigh].putCostMessage(costMsg);
    }

    public void receiveCostMessage() throws InterruptedException {
        int cnt = 0;
        while (cnt < child.size())
        {
            Message rcvdCostValueMsg = this.mailManager[this.agentNo].getCostMessage();
            this.cons_inbox.put(rcvdCostValueMsg.getSenderId(), rcvdCostValueMsg.getMsgContent());
            cnt += 1;
        }

    }

    public void sumRootChildCost() throws InterruptedException {
        double[] sumChildCost = new double[this.population];
        Arrays.fill(sumChildCost, 0.0);
        for(int baccha: child)
        {
            for(int i = 0; i < population; i++)
            {
                 sumChildCost[i] += this.cons_inbox.get(baccha)[i];
            }

        }
        for(int i = 0; i < population; i++)
        {
            this.globalRootCost[i] = sumChildCost[i] + this.cons_cost[i];
            this.globalRootCost[i] /= 2;
        }
    }

    public void setPbestGbest(){
        Arrays.fill(this.pbestParticleNo, -1);
        if(isMax) {}
        else{
            for(int i = 0; i < population; i++)
            {
                if(this.globalRootCost[i] < this.pbest_val[i])
                {
                    this.pbest_val[i] = this.globalRootCost[i];
                    this.pbest_position[i] = this.position[i];
                    this.pbestParticleNo[i] = i;

                }
                if(this.globalRootCost[i] < this.gbest_val)
                {
                    this.gbest_val = this.globalRootCost[i];
                    this.gbest_position = this.position[i];
                    this.gbestParticleNo = i;
                }
            }
        }
        this.pbestParticleNo[pbestParticleNo.length-1] = this.gbestParticleNo;
    }

    public void sendPbestGbestpositionMessage() throws InterruptedException {
        for(int baccha: child)
        {
            Message bestMsg = new Message(this.agentNo, baccha, 206, this.pbestParticleNo);
            this.mailManager[baccha].putBestMessage(bestMsg);
        }
    }

    public void receivePbestGbestPositionMessage() throws InterruptedException {

        Message rcvdBestMsg = this.mailManager[this.agentNo].getBestMessage();
        this.pbestParticleNo = rcvdBestMsg.getMsgContent();

        for(int i = 0; i < this.population; i++)
        {
            if(this.pbestParticleNo[i]!=-1)
            {
                this.pbest_position[i] = this.position[(int)(this.pbestParticleNo[i])];
            }

        }
        if(this.gbestParticleNo==-1 || this.position[(int)this.gbestParticleNo]!=this.position[(int)(this.pbestParticleNo[this.pbestParticleNo.length-1])])
        {
            this.suc_cnt += 1;
            this.fail_cnt = 0;
        }
        else {
            this.fail_cnt += 1;
            this.suc_cnt = 0;
        }
        this.gbestParticleNo = this.pbestParticleNo[this.pbestParticleNo.length-1];

        this.gbest_position = this.position[(int)(this.pbestParticleNo[this.pbestParticleNo.length-1])];

    }

    public void printPositions(int iteration){
        System.out.println("Position of " + this.agentName + " on iteration " + iteration + " = " + Arrays.toString(this.position));


    }


}