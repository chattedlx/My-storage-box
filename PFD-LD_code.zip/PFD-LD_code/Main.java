import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.time.*;

public class Main {

    public static void main(String args[]) throws IOException, InterruptedException {
        /** Parameters */
        /**
         * MAX_SAME_PROB = No. of runs for a problem
         * MAX_DIFF_PROB =  No. of problem
         * MAX_NODE = No. of Agents
         * w = Inertia Weight
         * c1 = Cognitive Constant
         * c2 = Social Constant
         */

        int MAX_SAME_PROB = 30;
        int MAX_DIFF_PROB = 1;
        int MAX_NODE = 60;
        double w = 0.9;
        double c1 = 0.9;
        double c2 = 0.1;
        Problem p1 = new Problem(0, 0, MAX_SAME_PROB, MAX_DIFF_PROB, MAX_NODE, w, c1, c2);
        p1.newProblem();

    }
}