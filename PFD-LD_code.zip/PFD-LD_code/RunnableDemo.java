import javax.swing.*;
import java.io.IOException;
import java.io.FileWriter;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

public class RunnableDemo implements Runnable {
    public static void fileWriterMethod(String filepath, String content) throws IOException {
        try (FileWriter fileWriter = new FileWriter(filepath)) {
            fileWriter.append(content);
        }
    }
    private Thread t;
    private String threadName;
    private int threadNo;
    private Agent agent;
    private int maxIteration;
    MailManager[] mailManagers;
    private int currentIter;
    String result = new String();
    private ConcurrentHashMap<String, Long> timeResults;

    public ConcurrentHashMap<String, Long> getTimeResults() {
        return timeResults;
    }

    public ConcurrentHashMap<Integer, ArrayList<Long>> getIterTimeResults() {
        return iterTimeResults;
    }

    public ArrayList<Long> getSimTimeArray() {
        return simTimeArray;
    }

    private ConcurrentHashMap<Integer, ArrayList<Long>> iterTimeResults;
    private ArrayList<Long> simTimeArray;

    public ArrayList<Long> getRunTimeArray() {
        return runTimeArray;
    }

    private ArrayList<Long> runTimeArray;

    public ArrayList<Double> getIterSol() {
        return iterSol;
    }

    private ArrayList<Double> iterSol;
    static volatile boolean exit = false;

    double[] bp;
    Problem problem;
    RunnableDemo( Problem problem, String agentType, MailManager[] mailManagers, int threadNo, String name, int maxIteration, Vector<Integer> neighbors, int parent, Vector<Integer> child, int population, double domain_lb, double domain_ub, boolean isMax, ArrayList<Edge> edgelist, int[][] indexToEdge, HashMap<Edge, Constraint> constraints, double w, double c1, double c2) {
        this.problem = problem;
        this.threadNo = threadNo;
        this.threadName = name;
        this.maxIteration = maxIteration;
        this.currentIter = 0;
        this.mailManagers = mailManagers;
        this.timeResults = new ConcurrentHashMap<>();
        this.iterTimeResults = new ConcurrentHashMap<>();
        this.simTimeArray = new ArrayList<>();
        this.iterSol = new ArrayList<>();
        this.runTimeArray = new ArrayList<>();


        this.bp = new double[population];
        if (agentType.equals("PFD-LD"))
            agent = new Agent(mailManagers, threadNo, neighbors, parent, child, population, domain_lb, domain_ub, maxIteration, isMax, edgelist, indexToEdge, constraints, w, c1, c2);
    }

    public void run() {

        try {
            long start = ManagementFactory.getThreadMXBean().getCurrentThreadUserTime();
            while (this.agent.getCurrentIter() < this.agent.getMaxIteration())
            {
                this.agent.getMailManager()[0].startNewIter();
                double decreasingW=0.9;
                this.agent.setW(decreasingW);

                if(this.agent.getCurrentIter()==0)
                {
                    this.agent.initValues();
                }

                else {
                    this.agent.updateValues();
                }
                this.agent.sendValueMessage();

                this.agent.receiveValueMessage();

                this.agent.calculateCost();

                this.agent.sendValueMessage_tocalbelief();
                this.agent.receiveValueMessage_tocalbelief();
                this.agent.calculateCost_tocalbelief();
                this.agent.receiveCostMessage_tocalbelief();
                this.agent.receiveCostMessage();
                if(threadNo!=0)
                {

                    this.agent.sendCostMessage_tocalbelief();
                    this.agent.sendCostMessage();
                    this.agent.receivePbestGbestPositionMessage();
                    this.agent.sendPbestGbestpositionMessage();
                }
                else
                {
                    this.agent.sumRootChildCost_tocalbelief();
                    this.agent.sumRootChildCost();
                    this.agent.setPbestGbest();
                    this.agent.sendPbestGbestpositionMessage();
                }
                if(threadNo==0)
                {
                    result += (String.valueOf( this.agent.getGbest_val_belief()) +'\n');
                    System.out.println("Iteration " + this.agent.getCurrentIter()+ " PFD-LD cost is " + this.agent.getGbest_val_belief());
                    long endTime = System.currentTimeMillis();
                    long diff = endTime - this.agent.starttime;
                    long iterEnd = ManagementFactory.getThreadMXBean().getCurrentThreadUserTime();
                    long iterDiffInMillis = (iterEnd-start) / 1000000;
                    this.simTimeArray.add(iterDiffInMillis);
                    this.runTimeArray.add(diff);
                    this.iterTimeResults.put(threadNo, this.simTimeArray);
                    this.iterSol.add(this.agent.getGbest_val());
                }
                this.agent.getMailManager()[0].makeTrue(threadNo);
                this.agent.getMailManager()[0].checkAllTrue(threadNo);
                this.agent.setCurrentIter(this.agent.getCurrentIter() + 1);
                Thread.sleep(50);
            }


        } catch (InterruptedException e) {
            System.out.println("Thread " +  threadName + " interrupted.");
        }
        if(threadNo==0)
        {
            int arrayNo = problem.problemNo * problem.MAX_SAME_Problem + problem.sameProbIt;

            int same_it = problem.sameProbIt + 1;
            try {
                if(same_it < problem.MAX_SAME_Problem)
                {
                    problem.setSameProbIt(same_it);
                    problem.newProblem();
                    fileWriterMethod("C:\\Users\\Lx_chat\\Desktop\\output1\\"+same_it+".txt",this.result);
                    this.result="";
                }
                else {
                    int diff_it = problem.problemNo + 1;
                    if(diff_it < problem.MAX_DIFF_PROB)
                    {
                        problem.setSameProbIt(0);
                        problem.setProblemNo(diff_it);
                        problem.newProblem();

                    }
                    else
                    {
                        fileWriterMethod("C:\\Users\\Lx_chat\\Desktop\\output1\\"+same_it+".txt",this.result);
                        System.out.println("complete!");
                        Date date2= new Date();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

//        System.out.println("Thread " +  threadName + " exiting.");


    }

    public void start () {

//        System.out.println("Starting " +  threadName );
        if (t == null) {

            t = new Thread (this, threadName);

            t.start ();


        }
    }
}